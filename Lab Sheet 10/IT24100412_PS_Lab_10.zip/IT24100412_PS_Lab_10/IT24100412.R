setwd("D:\\SLIIT\\2nd Year 1st Semester\\IT24100412_PS_Lab_10")
getwd()

#Exercise
#Question 1
#part 1
#Null Hypothesis (H0): Customers choose each snack type with equal probability. 
#Alternative Hypothesis (H1): Customers do not choose all snack types with equal probability. 

#part 2
observed <- c(120, 95, 85, 100)
chi_test <- chisq.test(x = observed, p = rep(0.25, 4))
chi_test

#part 3
#p-value (0.08966) > 0.05 ,we fail to reject the null hypothesis at the 5% significance level.